#------------------------------ funció de transformació dels enemics
def trasnEnemy(ene_men, ene_me, ene_m, cont_ali1, cont_ali2, cont_ali3, cont_ali4, cont_ali5, cont_ali6, cont_ali7, cont_ali8, cont_ali9, cont_ali10, cont_ali11, cont_ali12, cont_ali13, cont_ali14, cont_ali15, cont_ali16, cont_ali17, ene_men1, ene_men2, ene_men3, ene_men4, ene_men5, ene_men6, ene_men7, ene_men8, ene_men9, ene_men10, ene_men11, ene_men12, ene_men13, ene_men14, ene_men15, ene_men16, ene_men17) :
        # enemic 1
        if cont_ali1 == 0 :
            ene_men1 = ene_men
        if cont_ali1 == 1:
            ene_men1 = ene_me
        if cont_ali1 == 2:
            ene_men1 = ene_m
        # enemic 2
        if cont_ali2 == 0 :
            ene_men2 = ene_men
        if cont_ali2 == 1:
            ene_men2 = ene_me
        if cont_ali2 == 2:
            ene_men2 = ene_m
        #enemic 3
        if cont_ali3 == 0 :
            ene_men3 = ene_men
        if cont_ali3 == 1:
            ene_men3 = ene_me
        if cont_ali3 == 2:
            ene_men3 = ene_m
        # enemic 4
        if cont_ali4 == 0 :
            ene_men4 = ene_men
        if cont_ali4 == 1:
            ene_men4 = ene_me
        if cont_ali4 == 2:
            ene_men4 = ene_m
        # enemic 5
        if cont_ali5 == 0 :
            ene_men5 = ene_men
        if cont_ali5 == 1:
            ene_men5 = ene_me
        if cont_ali5 == 2:
            ene_men5 = ene_m
        # enemic 6
        if cont_ali6 == 0 :
            ene_men6 = ene_men
        if cont_ali6 == 1:
            ene_men6 = ene_me
        if cont_ali6 == 2:
            ene_men6 = ene_m
        #enemic 7
        if cont_ali7 == 0 :
            ene_men7 = ene_men
        if cont_ali7 == 1:
            ene_men7 = ene_me
        if cont_ali7 == 2:
            ene_men7 = ene_m
        # enemic 8
        if cont_ali8 == 0 :
            ene_men8 = ene_men
        if cont_ali8 == 1:
            ene_men8 = ene_me
        if cont_ali8 == 2:
            ene_men8 = ene_m
        # enemic 9
        if cont_ali9 == 0 :
            ene_men9 = ene_men
        if cont_ali9 == 1:
            ene_men9 = ene_me
        if cont_ali9 == 2:
            ene_men9 = ene_m
        # enemic 10
        if cont_ali10 == 0 :
            ene_men10 = ene_men
        if cont_ali10 == 1:
            ene_men10 = ene_me
        if cont_ali10 == 2:
            ene_men10 = ene_m
        #enemic 11
        if cont_ali11 == 0 :
            ene_men11 = ene_men
        if cont_ali11 == 1:
            ene_men11 = ene_me
        if cont_ali11 == 2:
            ene_men11 = ene_m
        # enemic 12
        if cont_ali12 == 0 :
            ene_men12 = ene_men
        if cont_ali12 == 1:
            ene_men12 = ene_me
        if cont_ali12 == 2:
            ene_men12 = ene_m
        # enemic 13
        if cont_ali13 == 0 :
            ene_men13 = ene_men
        if cont_ali13 == 1:
            ene_men13 = ene_me
        if cont_ali13 == 2:
            ene_men13 = ene_m
        # enemic 14
        if cont_ali14 == 0 :
            ene_men14 = ene_men
        if cont_ali14 == 1:
            ene_men14 = ene_me
        if cont_ali14 == 2:
            ene_men14 = ene_m
        #enemic 15
        if cont_ali15 == 0 :
            ene_men15 = ene_men
        if cont_ali15 == 1:
            ene_men15 = ene_me
        if cont_ali15 == 2:
            ene_men15 = ene_m
        # enemic 16
        if cont_ali16 == 0 :
            ene_men16 = ene_men
        if cont_ali16 == 1:
            ene_men16 = ene_me
        if cont_ali16 == 2:
            ene_men16 = ene_m
        # enemic 17
        if cont_ali17 == 0 :
            ene_men17 = ene_men
        if cont_ali17 == 1:
            ene_men17 = ene_me
        if cont_ali17 == 2:
            ene_men17 = ene_m
        return ene_men1, ene_men2, ene_men3, ene_men4, ene_men5, ene_men6, ene_men7, ene_men8, ene_men9, ene_men10, ene_men11, ene_men12, ene_men13, ene_men14, ene_men15, ene_men16, ene_men17
