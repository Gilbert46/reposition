# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 09:32:14 2019
@file: class_dragon.py
@description: del exercici anterior implementar-ho en 3 class
@author: Gilbert Viader
"""
class Joc :
    """
    la classe 'JOC', hi ha els mètodes
    """
def __init__(self) :
    #-------------------------------- 1. inicialització dels atributs
    self.done = False
    self.width = 600
    self.height = 500
    self.red = (242,111,111)
    self.live = 3
    self.level = 0
    #self.levelprev = -1
    #-------------------------------- 2. crearem una classe  (recollidor)
    self.collector = Collector()
    self.collector.speed = 0
    self.tret.speed = 0
    #-------------------------------- 3. crearem una classe (objecte del cel)
    self.falling = falling()
    self.falling.speed = 2
    #-------------------------------- 4. inicialització de la pantalla
    self.score = 0
    self.screen = pygame.display.set_mode((self.width, self.height), 0, 32)
    
def load_images(self, level) :
    """
    càrrega una imatge de fons, una imatge de recollidor i una d'objecte que cau 
    """
    dicci = self.list_img[level-1]
    carpeta = ".\\dragon\\"
    self.bg_img = pygame.image.load(carpeta + dicci["background"])
    self.bg_img = pygame.transform.scale(self.bg_img, (600, 500))
    self.fl_img = pygame.image.load(carpeta + dicci["fallinger"])
    self.fl_img = pygame.transform.scale(self.fl_img, (50, 50))
    self.co_img = pygame.image.load(carpeta + dicci["collector"])
    self.co_img = pygame.transform.scale(self.co_img, (120, 200))
    #------------------------------------------------ imatges afegides al joc
    self.ka_img = pygame.image.load(carpeta + dicci["kamehame"])
    self.ka_img = pygame.transform.scale(self.ka_img, (30, 80))
    self.en_img = pygame.image.load(carpeta + dicci["enemy"])
    self.en_img = pygame.transform.scale(self.en_img, (70, 140))
    self.ba_img = pygame.image.load(carpeta + dicci["ball_enemy"])
    self.ba_img = pygame.transform.scale(self.ba_img, (120, 200))
    
class Falling :
    """
    La classe 'Falling' hi ha
    """
    self.x = 0
    self.y = 0
    self.speed = 0

class Collector :
    """
    La classe 'Collector  hi ha
    """
    self.x = 0
    self.y = 0   
    self.speed = 0

#---------------------------------------------------------------------------
#--------------------------------------Procès inicial ----------------------
#---------------------------------------------------------------------------


